package labyrinthe;

/**
 *
 * @author INFO Professors team
 */
// enumeration des types des salles
public enum ESalle {
    NORMALE, ESCALIER_MONTANT, ESCALIER_DESCENDANT, ENTREE, SORTIE;
}
