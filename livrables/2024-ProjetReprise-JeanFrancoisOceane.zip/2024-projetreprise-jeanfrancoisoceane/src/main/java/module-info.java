module com.iutbx.projetlaby {
    requires javafx.controls;
    requires junit;
    requires org.jgrapht.core;
    requires java.desktop;
    exports application;
    exports labyrinthe;
    exports vue2D;
    exports vue2D.javafx;
}
